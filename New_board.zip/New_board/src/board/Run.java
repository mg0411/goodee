package board;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Run {
	public void run() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		loop:while(true) {
			System.out.print("번호입력:");
				String cmd = br.readLine();
				switch(cmd) {
				case "1"://글목록
					List.run();
					break;
				case "2"://글읽기
					break;
				case "3"://쓰기
					Write.run();
					break;
				case "4"://삭제
					Delete.run();
					break;
				case "e":
					System.out.println("프로그램 종료");
					break loop;
				default:
					System.out.println("다시입력하세요");
					break;
				}
			
			}
	}
}
