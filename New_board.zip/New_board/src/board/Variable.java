package board;

import java.time.LocalDate;

public class Variable {
	static int n =1;
	public int num;
	String title;
	String dec;
	String writer;
	public String date;
	
	Variable(String title,String dec,String writer){
		n+=1;
		num=n;
		this.title=title;
		this.dec=dec;
		this.writer=writer;
		LocalDate now = LocalDate.now();
		date = now.toString();
	}
}
