package board;

import java.util.ArrayList;
import java.util.Scanner;

public class Write {
	static ArrayList<Variable> list=new ArrayList<>();
	static void run() {
		Scanner sc = new Scanner(System.in);
		String title;
		while (true) {
			System.out.print("글제목:");
			title = sc.next();
			if (title.length() > 0) {
				break;
			} else {
				System.out.println("장난x");
			}
		}
		String dec;
		while (true) {
			System.out.print("글내용:");
			dec = sc.next();
			if (dec.length() > 0) {
				break;
			} else {
				System.out.println("장난x");
			}
		}
		String writer;
		while (true) {
			System.out.print("작성자:");
			writer = sc.next();
			if (writer.length() > 0) {
				break;
			} else {
				System.out.println("장난x");
			}
		}
		list.add(new Variable(title, dec, writer));
	}
}
