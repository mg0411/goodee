package fefefe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BoardDAO {
	Connection conn = null;
	int result = 0;
	Statement stmt = null;
	ResultSet rs = null;

	public BoardDAO() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public ArrayList<BoardDTO> select() {
		ArrayList<BoardDTO> li = new ArrayList<BoardDTO>();
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_board", "root", "root");
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from board");
			while (rs.next()) {
				BoardDTO dto = new BoardDTO(rs.getInt("num"),
						rs.getString("title"),
						rs.getString("writer"),
						rs.getString("content"),
						rs.getInt("cnt"));
				dto.setRegdate(rs.getString("regdate"));
				if(rs.getInt("state") == 1) {
					li.add(dto);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return li;
	}
	public BoardDTO selectOne(int num) {
		BoardDTO dto = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_board", "root", "root");
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from board where num=" + num);
			if (rs.next()) {
				dto = new BoardDTO(rs.getInt("num"),
						rs.getString("title"),
						rs.getString("writer"),
						rs.getString("content"),
						rs.getInt("cnt"));
				dto.setRegdate(rs.getString("regdate"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return dto;
	}
	public int insert(BoardDTO dto) {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_board", "root", "root");
			stmt = conn.createStatement();
			result = stmt.executeUpdate("insert into board (title,writer,content,regdate,cnt,state) values('" + dto.getTitle()
					+ "','" + dto.getWriter() + "','" + dto.getContent() + "',now(),0,1);");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {  
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	public int update(BoardDTO dto) {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_board", "root", "root");
			stmt = conn.createStatement();
			result = stmt.executeUpdate("update board set title='" + dto.getTitle() + "', content='" + dto.getContent()
					+ "' where num ="+dto.getNum());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	public void del_update(int num) {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_board", "root", "root");
			stmt = conn.createStatement();
			result = stmt.executeUpdate("update board set state=0 where num="+num );
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
