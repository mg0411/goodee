package com.Kisok;

public class Main {

	public static void main(String[] args) {	
		Display.title();
		Select.run();
				}
	}


				
				
				
