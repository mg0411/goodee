package com.peisia.mysqltest;

import java.sql.SQLException;

import com.peisia.util.Ci;
import com.peisia.util.Cw;
import com.peisia.util.Db;

public class ProcUpd {
	public static void run() {
		Cw.wn("내 글 목록");
		try {
			Db.result = Db.st.executeQuery("select * from content where current_id='"+Login.current_id+"'");
			while(Db.result.next()) {
				Cw.w("글번호: " + Db.result.getString("no")+' ');
				Cw.w("글제목: " + Db.result.getString("b_title")+' ');
				Cw.w("글내용: " + Db.result.getString("b_text")+'\n');
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String editNo = Ci.r("수정할 글번호를 입력해주세요:");
		String edTitle = Ci.rl("수정할제목을 입력해주세요:");
//		String edId = Login.current_id;
		String edContent = Ci.rl("글내용을 입력해주세요:");
		Db.dbExecuteUpdate("update content set b_title='" + edTitle + "'+,b_datetime=now(),b_text='" + edContent + "' where b_no=" + editNo);
	}
}
