package com.peisia.mysqltest;

import java.sql.SQLException;

import com.peisia.util.Ci;
import com.peisia.util.Cw;
import com.peisia.util.Db;

public class ProcWrite {
	public static void run() {
		String title = Ci.rl("제목을 입력해주세요:");
		String content = Ci.rl("글내용을 입력해주세요:");
	
		try {
			Db.st.executeUpdate("insert into content (b_title,current_id,b_datetime,b_text,b_hit)"
					+" values ('"+title+"','"+Login.current_id+"',now(),'"+content+"',0)");
			Cw.wn("글등록 완료");
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
}
