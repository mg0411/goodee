package com.peisia.mysqltest;

import com.peisia.c.board.display.Disp;
import com.peisia.util.Ci;
import com.peisia.util.Cw;
import com.peisia.util.Db;

public class ProcBoard {
	void run() {
		Disp.showTitle();
		
		loop: while (true) {
			Db.dbPostCount();
			Disp.showMainMenu();// 커넥션 생
			String cmd = Ci.r("명령입력: ");
			switch (cmd) {
			case "1": // 글리스트
				ProcList.run();
				break;
			case "2": // 글읽기
				ProcRead.run();
				break;
			case "3": // 글쓰기
				if(Login.current_id != null) {
					ProcWrite.run();
				}
				else {
					Cw.wn("로그인 필요");
				}
				break;
			case "4": // 글삭제
				if(Login.current_id != null) {
					ProcDel.run();
				}
				else {
					Cw.wn("로그인 필요");
				}
				break;
			case "5": // 글수정
				if(Login.current_id != null) {
					ProcUpd.run();
				}
				else {
					Cw.wn("로그인 필요");
				}
				break;
			case "0": // 관리자
				if(Login.current_id != null) {
					Manger.run();
				}
				else {
					Cw.wn("관리자로그인 필요");
				}
				break;
			case "e": // 프로그램 종료
				Cw.wn("프로그램종료&로그아웃");
				Login.current_id=null;
				break loop;
			case "m":
				Login.run();
			}
		}
	}
}