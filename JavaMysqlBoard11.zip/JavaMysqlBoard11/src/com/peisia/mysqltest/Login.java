package com.peisia.mysqltest;

import java.sql.SQLException;

import com.peisia.util.Ci;
import com.peisia.util.Cw;
import com.peisia.util.Db;

public class Login {
	static String current_id=null;
	public static void run() {
		
		Db.dbInit();
		String cmd;
		
		y: while (true) {
			System.out.println("*********************************");
			System.out.println("            MAIN_MENU");
			System.out.println("*********************************");
			cmd = Ci.r("비회원이용[x],로그인[a],회원가입하기[r]");
			int cnt=0;
			
			switch (cmd) {
			case "x":
				current_id=null;
				break y;
			case "a":
				String id = Ci.rl("id입력");
				String pw = Ci.rl("password입력");
				try {
					Db.result = Db.st.executeQuery("select count(*) from login_info where id='"+id+"'and pw='"+pw+"'");
					Db.result.next();
					if((Db.result.getString("count(*)").equals("1"))){
						Cw.wn("로그인 성공.");
						current_id=id;
					}
					else {
						Cw.wn("로그인 실패.");
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				break y;
			case "r":
				Cw.wn("회원가입 창");
				String new_id = Ci.rl("id");
				String new_pw = Ci.rl("password");
				try {
					Db.result = Db.st.executeQuery("select id from login_info where id='"+new_id+"'");
					while(Db.result.next()) {
						if(Db.result.getString("id").equals(new_id)) {
							cnt+=1;
						}
						else continue;
					}
					if (cnt >= 1) {
						Cw.wn("아이디가 이미 존재합니다.");
					} else {
						Db.dbExecuteUpdate("insert into login_info values('" + new_id + "','" + new_pw + "')");
						Cw.wn("회원가입 완료.");
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			}
		}
	}
}
