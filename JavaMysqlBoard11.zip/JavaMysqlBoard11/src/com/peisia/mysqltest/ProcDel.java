package com.peisia.mysqltest;

import java.sql.SQLException;

import com.peisia.util.Ci;
import com.peisia.util.Cw;
import com.peisia.util.Db;

public class ProcDel {
	public static void run() {
		Cw.wn("내 글 목록");
		try {
			Db.result = Db.st.executeQuery("select * from content where current_id='"+Login.current_id+"'and state!=0");
			while(Db.result.next()) {
				Cw.w("글번호: " + Db.result.getString("no")+' ');
				Cw.w("글제목: " + Db.result.getString("b_title")+' ');
				Cw.w("글내용: " + Db.result.getString("b_text")+'\n');
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		String delNo = Ci.r("삭제할 글번호를 입력해주세요:");
		
		Db.dbExecuteUpdate("update content set state =0 where no='"+delNo+"' and current_id='"+Login.current_id+"'");
		Db.dbExecuteUpdate("update comment set comment_state =0 where num="+delNo);
		}
}
