package com.peisia.mysqltest;

import java.sql.SQLException;
import java.util.ArrayList;

import com.peisia.util.Ci;
import com.peisia.util.Cw;
import com.peisia.util.Db;

public class ProcRead {
	public static String readNo;
	public static void run() {
		///////////////////////////// 글번호 출력
		try {
			Db.result = Db.st.executeQuery("select count(*) from content where state=1 ");// 글개수들어옴
			Db.result.next();
			if (Integer.parseInt(Db.result.getString("count(*)")) == 0) {
				Cw.w("글이 없습니다..");
			} else {
				try {
					Db.result = Db.st.executeQuery("select no from content where state=1 ");
					while (Db.result.next()) {

						Cw.w("번호: " + Db.result.getString("no") + ' ');
					}
					run1();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	////////////////////////////////////// 선택한 글번호에대한 내용 출력

	public static void run1() {
		
a:while(true) {
	
	readNo= Ci.r("읽을 글 번호를 입력해주세요:");
	
	try {
		
		Db.result = Db.st.executeQuery("select * from content where no ='" + readNo + "'and state=1");
		if(!Db.result.next()) {
			System.out.print("해당 글이 없습니다.");
		
		}else {
			
			String title = Db.result.getString("b_title"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			String content = Db.result.getString("b_text"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
			Cw.wn("글제목: " + title);
			Cw.wn("글내용: " + content);
			break a;
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
}

		Integer.parseInt(ProcRead.readNo);
		/////////////////// 해당번호에 대한 댓글목록
		System.out.println("*********** 댓글 목록 ***********");
		try {
			Db.result = Db.st.executeQuery("select count(*) from comment");// 글개수들어옴
			Db.result.next();

			Db.result = Db.st.executeQuery("select * from comment where num=" + readNo);
			while (Db.result.next()) {
				System.out.print(Db.result.getString("comment_text") + " ");
				System.out.print(Db.result.getString("comment_date") + '\n');
			}
			System.out.println();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (Login.current_id != null) {

			String cmd;
			a: while (true) {
				cmd = Ci.r("이전단계[x], 댓글달기[r]");
				switch (cmd) {
				case "x":
					break a;
				case "r":
					Db.dbExecuteUpdate("insert into comment(num,comment_text,comment_date) values ('" + readNo + "','"+ Ci.rl("댓글 작성") + "',now())");
							

					break;
				}
			}
		} else {
			Cw.wn("댓글작성은 로그인 필요");
		}

	}
}