package com.peisia.mysqltest;

import com.peisia.util.Cw;

public class Manger {
	public static void run() {
		if (Login.current_id.equals("wjdalsrl")) {

		} else {
		}
		Cw.w("id가 다릅니다");

	}
}
