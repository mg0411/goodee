package com.peisia.mysqltest;

public class Main {
	public static void main(String[] args) {
		Login.run();
		ProcBoard procBoard=new ProcBoard();
		procBoard.run();
	}
	
	

}