package board;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		///////////////////////////////////////장식
		String star = "*";
		for (int i = 0; i < 30; i++) {
			System.out.print(star);
		}
		System.out.print("\n            " + "게시판" + '\n');
		for (int i = 0; i < 30; i++) {
			System.out.print(star);
		}
		System.out.println('\n'+"[1.글 리스트/2.글읽기/3.글쓰기/4.글삭제/e.종료]");
		
		////////////////////////////////////////시작부분
		Run r = new Run();
		r.run();
	}
}
