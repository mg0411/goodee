package board;

import java.util.Scanner;

public class Delete {
	static void run() {
		System.out.print("삭제할 글번호을 선택하세요");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		for(Variable x : Write.list) {
			if(num==Write.list.indexOf(x)+1) {
				Write.list.remove(num-1);
				break;
			}
		}
	}
}
