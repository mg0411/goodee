package board;

import java.time.LocalDateTime;

public class Variable {

	String title;
	String dec;
	String writer;
	public String date;
	
	Variable(String title,String dec,String writer){

		this.title=title;
		this.dec=dec;
		this.writer=writer;
		LocalDateTime  now = LocalDateTime .now();
		date = now.toString();
	}
}
