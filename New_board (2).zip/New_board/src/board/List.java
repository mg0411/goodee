package board;

public class List {
	static void run() {
		System.out.println("리스트목록");
		for(Variable x : Write.list) {
			//글번호는 인덱스번호 이용해서 출력했습니다
			System.out.print("글번호: "+((Write.list.indexOf(x))+1));
			System.out.print("글제목: "+x.title);
			System.out.print("글내용: "+x.dec);
			System.out.print("작성자: "+x.writer);
			System.out.println("작성일자: "+x.date);
		}
	}
}
