package com.Kisok;

public class Common {
	public static void dw(String s) {
		System.out.print(s);
	}
}
