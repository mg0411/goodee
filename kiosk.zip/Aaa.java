package com.Kisok;

public class Aaa {
	final  String DOT="*";
	public void line() {
		for(int i= 0 ; i < 32 ; i++ ) {
			Common.dw(DOT);
		}
		Common.dw("\n");
		System.out.println("************고양이 카페************");
		Common.dw("********************************");
		Common.dw("\n");
	}
	
	
}
