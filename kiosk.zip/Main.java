package com.Kisok;

public class Main {

	public static void main(String[] args) {
		Aaa st = new Aaa();
		st.line();
		kisok.run();
					
				}
	}


				
				
				
