/**
 * 
 */
/**
 * @author GDJ 59
 *
 */
module javaboard {
	requires java.sql;
}