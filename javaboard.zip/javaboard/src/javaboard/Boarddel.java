package javaboard;

import java.sql.SQLException;

public class Boarddel {
public void delete() {
	
	try {
		Driver.rs=Driver.st.executeQuery("select no from test");
		while(Driver.rs.next()) {
			System.out.print("글 번호:"+Driver.rs.getString("title")+'\n');
			
		}
		System.out.println("삭제할 글 번호 입력:");
		int num = Main.sc.nextInt();
		int n = Driver.st.executeUpdate("update test set state=0 where no="+num);
		System.out.println(n+"번 글 삭제됨");
	} catch (SQLException e) {
		e.printStackTrace();
	}
}
}
