package javaboard;

import java.sql.SQLException;

public class Boardwrite {
	public void write() {
		System.out.print("글 제목");
		String str = Main.sc.next();
		System.out.print("글 본문");
		String str1 = Main.sc.next();
		try {
			int a = Driver.st.executeUpdate("insert into test(title,content) values('"+str+"','"+str1+"')");
			System.out.print(a+"행 처리됨");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}


