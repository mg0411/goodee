package javaboard;

import java.sql.SQLException;

public class Boardlist {
	public void list() {
		
		try {
			Driver.rs=Driver.st.executeQuery("select no from test");
			while(Driver.rs.next()) {
				System.out.print("글 번호:"+Driver.rs.getString("title")+'\n');
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
}
	}
