package javaboard;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Driver {
	static Statement st=null;
	static ResultSet rs=null;
//드라이버로드 && 커넥션 수행
	 static void load() {
		try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection cmt = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
				st = cmt.createStatement();
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}catch(SQLException e) {
				e.printStackTrace();
			}
	}
}
	 

