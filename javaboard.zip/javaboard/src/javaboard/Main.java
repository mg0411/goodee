package javaboard;

import java.util.Scanner;

public class Main {

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.print("[1]글목록 [2]글읽기 [3]글쓰기 [4]글삭제 [e]프로그램종료");
		a: while(true) {
			String str = sc.next();
			switch(str) {
			case"1":
				Boardlist sr = new Boardlist();
				sr.list();
				break;
			case"2":
				Boardread br = new Boardread();
				br.read();
				break;
			case"3":
				Boardwrite bw = new Boardwrite();
				bw.write();
				break;
			case"4":
				Boarddel bd = new Boarddel();
				bd.delete();
				break;
			case"e":
				System.out.println("프로그램 종료");
				break a;
			}
		}
	}
}
