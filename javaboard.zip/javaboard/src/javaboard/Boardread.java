package javaboard;

import java.sql.SQLException;

public class Boardread {
public void read() {
	
	try {
		Driver.rs=Driver.st.executeQuery("select no from test");
		while(Driver.rs.next()) {
			System.out.print(Driver.rs.getString("title")+' ');
			System.out.print(Driver.rs.getString("content")+'\n');
		}
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	
}
}
